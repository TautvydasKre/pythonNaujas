m = [1, 3, 8, 99, 42, 4, 22, 77]

m.sort(reverse=True)

print(m)


tekstas = ['yy', 'a', 'abc', 'dce', 'tyu', 'jkl', 'rda', 'vvhfff']
tekstas.sort(key=len, reverse=True)
print(tekstas)